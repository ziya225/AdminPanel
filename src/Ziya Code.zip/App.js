// Name : Mohd Ziya
// Email : mdziya9236@gmail.com
// DOI : 06-10-22
import axios from 'axios';
import { useEffect, useState } from 'react';
function App() {
  //const [userData, setUserData] = useState(null);
  useEffect(() => {
    axios.get('http://34.198.81.140/attendance.json').then((response) => {
      //setUserData(response.data);
      // console.log(userData);
      let finalData = calCulateSalary(response.data);
      console.log(finalData);
    });
  }, []);

  function calCulateSalary(data) {
    let allData = data.map((item, index) => {
      if (item.gender == 'Male') {
        if (item.total_hours > 9.25) {
          const normal_time = 9.25 * item.weekday;
          const overtime_hours = (item.total_hours - 9.25) * item.weekday;
          let overtime_salary = (overtime_hours / 24) * item.per_day_salary;
          const normal_salary = (normal_time / 24) * item.per_day_salary;
          if (
            item.designation == 'Worker' ||
            item.designation == 'Supervisor'
          ) {
            if (item.weekday > 6) {
              overtime_salary =
                overtime_salary + item.total_hours * item.per_day_salary * 2;
            }
          }
          const tot_salary = overtime_salary + normal_salary;
          return { ...item, calculate: tot_salary };
        } else if (item.total_hours < 9.25 && item.total_hours > 4) {
          const normal_time = 9.25 * item.weekday;
          const overtime_hours = (item.total_hours - 9.25) * item.weekday;
          let overtime_salary =
            ((overtime_hours / 24) * item.per_day_salary) / 2;
          const normal_salary = ((normal_time / 24) * item.per_day_salary) / 2;
          if (
            item.designation == 'Worker' ||
            item.designation == 'Supervisor'
          ) {
            if (item.weekday > 6) {
              overtime_salary =
                overtime_salary + item.total_hours * item.per_day_salary * 2;
            }
          }
          const tot_salary = overtime_salary + normal_salary;
          return { ...item, calculate: tot_salary };
        } else {
          const normal_time = 9.25 * item.weekday;
          const overtime_hours = (item.total_hours - 9.25) * item.weekday;
          let overtime_salary = 0;
          const normal_salary = 0;
          if (
            item.designation == 'Worker' ||
            item.designation == 'Supervisor'
          ) {
            if (item.weekday > 6) {
              overtime_salary =
                overtime_salary + item.total_hours * item.per_day_salary * 2;
            }
          }
          const tot_salary = overtime_salary + normal_salary;
          return { ...item, calculate: tot_salary };
        }
      } else {
        if (item.total_hours > 9.25) {
          const normal_time = 9.25 * item.weekday;
          const overtime_hours = (item.total_hours - 9.25) * item.weekday;
          let overtime_salary = (overtime_hours / 24) * item.per_day_salary;
          const normal_salary = (normal_time / 24) * item.per_day_salary;
          if (
            item.designation == 'Worker' ||
            item.designation == 'Supervisor'
          ) {
            if (item.weekday > 6) {
              overtime_salary =
                overtime_salary + item.total_hours * item.per_day_salary * 2;
            }
          }
          let double_overtime_hours = 0;
          if (item.total_hours > 9.75 && item.weekday < 7) {
            double_overtime_hours =
              (((item.total_hours - 9.75) * item.weekday) / 24) *
              item.per_day_salary *
              2;
          }

          const tot_salary =
            overtime_salary + normal_salary + double_overtime_hours;
          return { ...item, calculate: tot_salary };
        } else if (item.total_hours < 9.25 && item.total_hours > 4) {
          const normal_time = 9.25 * item.weekday;
          const overtime_hours = (item.total_hours - 9.25) * item.weekday;
          let overtime_salary =
            ((overtime_hours / 24) * item.per_day_salary) / 2;
          const normal_salary = ((normal_time / 24) * item.per_day_salary) / 2;
          if (
            item.designation == 'Worker' ||
            item.designation == 'Supervisor'
          ) {
            if (item.weekday > 6) {
              overtime_salary =
                overtime_salary + item.total_hours * item.per_day_salary * 2;
            }
          }
          const tot_salary = overtime_salary + normal_salary;
          return { ...item, calculate: tot_salary };
        } else {
          const normal_time = 9.25 * item.weekday;
          const overtime_hours = (item.total_hours - 9.25) * item.weekday;
          let overtime_salary = 0;
          const normal_salary = 0;
          if (
            item.designation == 'Worker' ||
            item.designation == 'Supervisor'
          ) {
            if (item.weekday > 6) {
              overtime_salary =
                overtime_salary + item.total_hours * item.per_day_salary * 2;
            }
          }
          const tot_salary = overtime_salary + normal_salary;
          return { ...item, calculate: tot_salary };
        }
      }
    });

    let male = allData.filter(({ gender }) => gender === 'Male');
    //console.log(male);
    let male_total_cal = male.reduce((a, b) => ({
      calculate: a.calculate + b.calculate,
    }));
    // console.log(male_total_cal.calculate);

    let female = allData.filter(({ gender }) => gender === 'Female');
    let female_total_cal = female.reduce((a, b) => ({
      calculate: a.calculate + b.calculate,
    }));
    let new_data = null;
    if (male_total_cal.calculate < female_total_cal.calculate) {
      new_data = allData.map((item, index) => {
        if (item.gender == 'Male') {
          let extra_salary = item.calculate * 0.02;
          return { ...item, calculate: item.calculate + extra_salary };
        } else {
          return item;
        }
      });
    } else {
      new_data = allData.map((item, index) => {
        if (item.gender == 'Female') {
          let extra_salary = item.calculate * 0.02;
          return { ...item, calculate: item.calculate + extra_salary };
        } else {
          return item;
        }
      });
    }
    return new_data;
    // console.log(allData);
    // console.log(new_data);
    // console.log(female_total_cal.calculate);
    // console.log(female_total_cal[0]);
    //console.log(total_hours);
  }
  return <div className="">hi</div>;
}

export default App;
